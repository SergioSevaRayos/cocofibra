// src/scripts/preguntas.js
document.addEventListener("DOMContentLoaded", () => {
    const items = [...document.querySelectorAll(".faq-item")];

    const SVG_PLUS = `
        <svg width="22" height="22" viewBox="0 0 24 24">
            <path d="M12 5v14M5 12h14"
                  stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>`;
    const SVG_CLOSE = `
        <svg width="22" height="22" viewBox="0 0 24 24">
            <path d="M6 6l12 12M18 6L6 18"
                  stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>`;

    items.forEach((item) => {
        const button = item.querySelector("[data-faq-button]");
        const icon = item.querySelector(".faq-icon");

        if (!button || !icon) return;

        icon.innerHTML = SVG_PLUS;

        button.addEventListener("click", () => {
            const open = item.classList.contains("active");

            // Cerrar otros
            items.forEach((i) => {
                if (i !== item) {
                    i.classList.remove("active");
                    const ic = i.querySelector(".faq-icon");
                    if (ic) ic.innerHTML = SVG_PLUS;
                }
            });

            // Abrir/cerrar este
            if (open) {
                item.classList.remove("active");
                icon.innerHTML = SVG_PLUS;
            } else {
                item.classList.add("active");
                icon.innerHTML = SVG_CLOSE;
            }
        });
    });

    // Entrada suave
    const observer = new IntersectionObserver(
        (entries) => {
            entries.forEach((e) => {
                if (e.isIntersecting) {
                    e.target.classList.add("entered");
                    observer.unobserve(e.target);
                }
            });
        },
        { threshold: 0.1 }
    );

    items.forEach((item) => observer.observe(item));
});
export {};