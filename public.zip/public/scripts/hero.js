import { animate } from "motion";

window.addEventListener("DOMContentLoaded", () => {
  const main = document.querySelector(".hero-main");
  if (!main) return;

  animate(
    main,
    { opacity: [0, 1], x: ["-40px", 0] },
    { duration: 0.45, easing: "cubic-bezier(0.16, 1, 0.3, 1)" }
  );
});
