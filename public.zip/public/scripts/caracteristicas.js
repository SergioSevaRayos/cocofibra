import { animate, inView } from "motion";

// Los scripts tipo 'module' ya son deferidos, no necesitas DOMContentLoaded
// pero si prefieres seguridad, verifica el readyState.

const initAnimations = () => {
    const items = document.querySelectorAll(".feature-item");

    if (items.length === 0) return;

    // Nota: Quitamos las llaves { } alrededor de 'element'
    inView(".feature-item", (element) => {

        // Ya no necesitamos verificar si es HTMLElement, inView garantiza que lo es
        
        // Evitar animación repetida
        if (element.dataset.animated === "true") return;
        element.dataset.animated = "true";

        // Obtener índice real
        const index = Array.from(items).indexOf(element);
        const isLeftColumn = index % 2 === 0;

        animate(
            element,
            { 
                x: [isLeftColumn ? "-100vw" : "100vw", 0],
                opacity: [0, 1] // Agregamos opacidad para que se vea más suave
            },
            {
                duration: 0.8, // Un poco más lento para que se aprecie mejor
                easing: "cubic-bezier(0.17, 0.55, 0.55, 1)",
                delay: 0.1 // Un pequeño delay para evitar tirones
            }
        );
    });
};

// Ejecutar
initAnimations();