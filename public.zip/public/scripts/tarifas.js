import { animate, inView } from "motion";

document.addEventListener("DOMContentLoaded", () => {
  const selector = ".tarifa-item";
  const items = [...document.querySelectorAll(selector)];

  if (!items.length) return;

  // Fuerza estado inicial SIEMPRE
  items.forEach((el) => {
    el.dataset.animated = "false";
    el.style.opacity = 0;
    el.style.transform = "translateY(40px)";
  });

  function animateCard(element, index = 0) {
    animate(
      element,
      { opacity: [0, 1], y: [40, 0] },
      {
        duration: 0.55,
        easing: "cubic-bezier(.17,.55,.55,1)",
        delay: index * 0.08,
      }
    );
  }

  inView(selector, (element) => {
    if (element.dataset.animated === "true") return;

    const visibleItems = items.filter(
      (i) => !i.classList.contains("hidden")
    );

    const index = visibleItems.indexOf(element);

    element.dataset.animated = "true";
    animateCard(element, index);
  });

  document.addEventListener("tarifas:updated", () => {
    const visibleItems = items.filter(
      (i) => !i.classList.contains("hidden")
    );

    visibleItems.forEach((el, index) => {
      el.dataset.animated = "true";
      animateCard(el, index);
    });
  });
});
