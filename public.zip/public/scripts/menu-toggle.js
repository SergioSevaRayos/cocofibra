// menu-toggle.js limpio y seguro por orientación
(function () {

  function isPortrait() {
    return window.matchMedia("(orientation: portrait)").matches;
  }

  function initMenu() {
    // Si estamos en landscape → NO montar menú móvil
    if (!isPortrait()) {
      destroyMenu();
      return;
    }

    const btn = document.getElementById("menu-btn");
    const panel = document.getElementById("mobile-menu");
    if (!btn || !panel) return;

    // Evitar doble binding
    if (btn.dataset.bound === "true") return;
    btn.dataset.bound = "true";

    let isOpen = false;

    function openMenu() {
      panel.classList.remove("translate-x-full");
      panel.setAttribute("aria-hidden", "false");

      const b1 = document.getElementById("bar1");
      const b2 = document.getElementById("bar2");
      const b3 = document.getElementById("bar3");

      if (b1 && b2 && b3) {
        b1.style.transform = "rotate(45deg) translate(6px,6px)";
        b2.style.opacity = "0";
        b3.style.transform = "rotate(-45deg) translate(6px,-6px)";
      }

      document.documentElement.style.overflow = "hidden";
      isOpen = true;
    }

    function closeMenu() {
      panel.classList.add("translate-x-full");
      panel.setAttribute("aria-hidden", "true");

      const b1 = document.getElementById("bar1");
      const b2 = document.getElementById("bar2");
      const b3 = document.getElementById("bar3");

      if (b1 && b2 && b3) {
        b1.style.transform = "none";
        b2.style.opacity = "1";
        b3.style.transform = "none";
      }

      document.documentElement.style.overflow = "";
      isOpen = false;
    }

    btn.addEventListener("click", () => {
      isOpen ? closeMenu() : openMenu();
    });

    // Cierra con Escape
    window.addEventListener("keydown", (ev) => {
      if (ev.key === "Escape") closeMenu();
    });

    // Cierra al pulsar links
    panel.querySelectorAll("a").forEach((a) =>
      a.addEventListener("click", closeMenu)
    );
  }

  function destroyMenu() {
    const btn = document.getElementById("menu-btn");
    const panel = document.getElementById("mobile-menu");

    if (!btn || !panel) return;

    // Quitar listeners y resets
    btn.dataset.bound = "false";
    panel.classList.add("translate-x-full");
    panel.setAttribute("aria-hidden", "true");

    document.documentElement.style.overflow = "";
  }

  // Inicializar según orientación
  function handleOrientation() {
    if (isPortrait()) initMenu();
    else destroyMenu();
  }

  // Activar manejador inicial
  window.addEventListener("DOMContentLoaded", handleOrientation);

  // Reaccionar cuando el usuario gira el móvil
  window.matchMedia("(orientation: portrait)").addEventListener("change", handleOrientation);

})();
