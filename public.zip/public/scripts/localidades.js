import { animate, inView } from "motion";

document.addEventListener("DOMContentLoaded", () => {
    const items = document.querySelectorAll(".localidad-item");
    if (!items.length) return;

    inView(".localidad-item", (element) => {
        if (element.dataset.animated === "true") return;
        element.dataset.animated = "true";

        const index = Array.from(items).indexOf(element);

        animate(
            element,
            { opacity: [0, 1], y: [40, 0] },
            {
                duration: 0.6,
                easing: "cubic-bezier(.17,.55,.55,1)",
                delay: index * 0.1
            }
        );
    });
});
